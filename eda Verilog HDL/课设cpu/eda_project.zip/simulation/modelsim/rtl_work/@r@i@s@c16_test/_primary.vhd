library verilog;
use verilog.vl_types.all;
entity RISC16_test is
    generic(
        WIDTH           : integer := 8
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of WIDTH : constant is 1;
end RISC16_test;
