library verilog;
use verilog.vl_types.all;
entity \bus\ is
    port(
        CLK             : in     vl_logic;
        Rstn            : in     vl_logic;
        DW              : in     vl_logic;
        DAddr           : in     vl_logic_vector(31 downto 0);
        WData           : in     vl_logic_vector(31 downto 0);
        RData           : out    vl_logic_vector(31 downto 0);
        M_DW            : out    vl_logic;
        M_Addr          : out    vl_logic_vector(7 downto 0);
        M_WData         : out    vl_logic_vector(31 downto 0);
        M_RData         : in     vl_logic_vector(31 downto 0);
        U_mp_cs_l       : out    vl_logic;
        U_mp_addx       : out    vl_logic_vector(2 downto 0);
        U_mp_data_to_uart: out    vl_logic_vector(7 downto 0);
        U_mp_data_from_uart: in     vl_logic_vector(7 downto 0);
        U_mp_rd_l       : out    vl_logic;
        U_mp_wr_l       : out    vl_logic
    );
end \bus\;
