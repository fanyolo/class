library verilog;
use verilog.vl_types.all;
entity sync is
    port(
        clk_in          : in     vl_logic;
        sys_rst_l       : in     vl_logic;
        d               : in     vl_logic;
        q               : out    vl_logic
    );
end sync;
