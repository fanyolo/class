library verilog;
use verilog.vl_types.all;
entity RISC16_Uart is
    port(
        CLK             : in     vl_logic;
        Rstn            : in     vl_logic;
        RXD             : in     vl_logic;
        TXD             : out    vl_logic
    );
end RISC16_Uart;
