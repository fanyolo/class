library verilog;
use verilog.vl_types.all;
entity RISC16 is
    generic(
        Rstn_Addr       : integer := 0
    );
    port(
        CLK             : in     vl_logic;
        Rstn            : in     vl_logic;
        InstAddr        : out    vl_logic_vector(31 downto 0);
        Inst            : in     vl_logic_vector(15 downto 0);
        DW              : out    vl_logic;
        DAddr           : out    vl_logic_vector(31 downto 0);
        WData           : out    vl_logic_vector(31 downto 0);
        RData           : in     vl_logic_vector(31 downto 0)
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of Rstn_Addr : constant is 1;
end RISC16;
