library verilog;
use verilog.vl_types.all;
entity one_shot is
    port(
        sys_rst_l       : in     vl_logic;
        clk_in          : in     vl_logic;
        d               : in     vl_logic;
        q               : out    vl_logic
    );
end one_shot;
