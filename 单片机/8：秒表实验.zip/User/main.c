#include "stm32f10x.h"

// 函数声明
void SysTick_Initialization(uint32_t delay, uint8_t priority);
void GPIOA_Initialization(void);
void GPIOB_Initialization(void);
void GPIOC_Initialization(void);
void SysTick_Handler(void);
void KeyScan(void);
void KeyDriver(void);
void KeyAction(uint32_t code);
void Timer_Update(void);

// 全局变量
uint8_t KeySta[2] = {0, 0}; // 按键当前状态
uint8_t TimerRunning = 0;    // 计时器运行状态
uint32_t TimerCount = 0;     // 计时器计数值（每10ms增加1）
uint8_t LEDState = 0;        // 红色LED状态

int main(void)
{
    SysTick_Initialization(2, 15); // 定时2ms，优先级15
    GPIOA_Initialization();        // 初始化GPIOA
    GPIOB_Initialization();        // 初始化GPIOB
    GPIOC_Initialization();        // 初始化GPIOC
    GPIOB->ODR = 0xFFFFFFFF;       // 初始化GPIOB输出为高电平（LED灭）

    while (1)
    {
        KeyDriver(); // 按键驱动
    }
}

// GPIOA初始化（按键KEY1）
void GPIOA_Initialization(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0; // PA0 - 按键KEY1
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

// GPIOC初始化（按键KEY2）
void GPIOC_Initialization(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13; // PC13 - 按键KEY2
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
}

// GPIOB初始化（LED）
void GPIOB_Initialization(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_5; // PB0 - 绿色LED, PB1 - 蓝色LED, PB5 - 红色LED
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_SetBits(GPIOB, GPIO_Pin_5);
}

// SysTick初始化
void SysTick_Initialization(uint32_t delay, uint8_t priority)
{
    SysTick->CTRL = 0;
    SysTick->LOAD = (72000) * delay; // 2ms定时
    NVIC_SetPriority(SysTick_IRQn, priority); // 设置优先级
    SysTick->VAL = 0;
    SysTick->CTRL = 0x07; // 使能SysTick
}

// 按键扫描函数（在SysTick中断中调用）
void KeyScan(void)
{
    uint32_t i;
    static uint8_t keybuf[2] = {0x00, 0x00}; // 按键扫描缓冲区
    uint8_t KEY1, KEY2;

    // 将按键值移入缓冲区
    KEY1 = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0);
    KEY2 = GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13);
    keybuf[0] = (keybuf[0] << 1) | KEY1;
    keybuf[1] = (keybuf[1] << 1) | KEY2;

    // 消抖后更新按键状态
    for (i = 0; i < 2; i++)
    {
        if (keybuf[i] == 0x00) // 连续8次扫描值为0，按键按下
        {
            KeySta[i] = 0;
        }
        else if (keybuf[i] == 0xFF) // 连续8次扫描值为1，按键释放
        {
            KeySta[i] = 1;
        }
    }
}

// 按键驱动函数（在主循环中调用）
void KeyDriver(void)
{
    uint32_t i;
    static uint8_t backup[2] = {0, 0}; // 按键值备份

    for (i = 0; i < 2; i++)
    {
        if (backup[i] != KeySta[i]) // 检测按键状态变化
        {
            if (backup[i] != 0) // 按键按下时执行动作
            {
                KeyAction(i); // 调用按键动作函数
            }
            backup[i] = KeySta[i]; // 更新备份值
        }
    }
}

// 按键动作函数
void KeyAction(uint32_t code)
{
    switch (code)
    {
    case 0: // KEY1 - 启动/停止
        TimerRunning = !TimerRunning; // 切换计时器状态
        break;
    case 1: // KEY2 - 复位
        TimerRunning = 0;       // 停止计时器
        TimerCount = 0;         // 清零计数值
        LEDState = 0;           // 关闭红色LED
        GPIO_SetBits(GPIOB, GPIO_Pin_5); // 红色LED灭
        break;
    default:
        break;
    }
}

// 计时器更新函数（在SysTick中断中调用）
void Timer_Update(void)
{
    if (TimerRunning)
    {
        TimerCount++; // 每10ms增加1
        if (TimerCount % 20 == 0) // 每0.2秒（20 * 10ms）
        {
            LEDState = !LEDState; // 切换红色LED状态
            if (LEDState)
            {
                GPIO_SetBits(GPIOB, GPIO_Pin_5); // 红色LED亮
            }
            else
            {
                GPIO_ResetBits(GPIOB, GPIO_Pin_5); // 红色LED灭
            }
        }
    }
}

// SysTick中断服务函数
void SysTick_Handler(void)
{
    KeyScan();   // 按键扫描
    Timer_Update(); // 更新计时器
    SCB->ICSR |= 1 << 25; // 清除中断标志
}
