//  DMA1_CH1,  M2M - Interrupt Mode
//  ??USART1??????????? (??????DMA??)
//  ??printf?scanf?getchar???
//  Keil ??C/C++???"Use MicroLIB"

#include <stdio.h>
#include "stm32f10x.h"

// Global Buffers
uint32_t srcbuffer[10] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A};
uint32_t dstbuffer[10] = {0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A}; // Initial content will be overwritten

// Function Prototypes
void USART1_IOInit(void);
void NVIC_USART1Enable(void);
void USART1Init(uint32_t BAUDRATE);
void USART1_IRQHandler(void); // For USART RX, not directly related to DMA completion
int fputc(int ch, FILE *f);
int fgetc(FILE *f);

void DMA_M2M_Interrupt_Init(DMA_Channel_TypeDef* DMA_CHx, uint32_t src, uint32_t dst, uint32_t ilen);
void DMA1_Channel1_NVIC_Init(void);
// DMA1_Channel1_IRQHandler is the standard name for the ISR

void Show_Message(void);

// Volatile flag to be set by ISR, can be checked by main if needed (optional for this lab's core goal)
// volatile uint8_t dma_transfer_status = 0; // 0: pending, 1: complete, 2: error


int main(void)
{
    USART1Init(9600);  // Initialize USART1 with baud rate 9600
    printf("USART1 Initialized. DMA Test Starting (Interrupt Mode)...\n");
    printf("Initial dstbuffer[0] = 0x%02X (%u)\n", (unsigned int)dstbuffer[0], (unsigned int)dstbuffer[0]);

    DMA1_Channel1_NVIC_Init(); // Initialize NVIC for DMA1 Channel 1 interrupt

    // Initialize DMA for memory-to-memory transfer with interrupts enabled
    DMA_M2M_Interrupt_Init(DMA1_Channel1, (uint32_t)srcbuffer, (uint32_t)dstbuffer, 10);

    // Start DMA transfer
    DMA_Cmd(DMA1_Channel1, ENABLE);
    printf("DMA Transfer Started. CPU is free or can perform other tasks.\n");
    printf("Completion/Error message will be sent from DMA ISR.\n");

    while(1)
    {
        // Main loop can perform other tasks or wait for DMA completion via a flag if needed.
        // For this example, the notification is handled entirely by the ISR.
        // Example: if (dma_transfer_status != 0) { /* process dma_transfer_status */ dma_transfer_status = 0; }
    }
}

// USART1 I/O Initialization
void USART1_IOInit(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  // Enable GPIOA clock

    // Configure PA9 (TX) as Alternate Function Push-Pull
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // Configure PA10 (RX) as Input Floating
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

// USART1 NVIC Configuration (for USART RX interrupt)
void NVIC_USART1Enable(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); // Ensure this matches your system's group config

    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; // Example priority
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;        // Example priority
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

// USART1 Initialization with given baud rate
void USART1Init(uint32_t BAUDRATE)
{
    USART_InitTypeDef USART_InitStructure;
    USART1_IOInit();  // Initialize USART1 GPIO

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);  // Enable USART1 clock

    USART_InitStructure.USART_BaudRate = BAUDRATE;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART1, &USART_InitStructure);

    NVIC_USART1Enable();  // Enable USART1 RX interrupt (can be kept for general USART use)
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); // Enable USART1 RX interrupt

    USART_Cmd(USART1, ENABLE);  // Enable USART1
}

// USART1 Interrupt Handler (echoes received characters - independent of DMA)
void USART1_IRQHandler(void)
{
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        uint8_t dat = USART_ReceiveData(USART1);
        USART_SendData(USART1, dat);
        // Wait for TC is good practice for robust echo, but can be slow
        // while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
        USART_ClearITPendingBit(USART1, USART_IT_RXNE); // Clear RXNE pending bit if not cleared by reading DR
    }
}

// USART1 printf function for serial output
int fputc(int ch, FILE *f)
{
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    USART_SendData(USART1, (uint16_t)ch);
    return ch;
}

// USART1 scanf function for serial input
int fgetc(FILE *f)
{
    while (USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == RESET);
    return (int)USART_ReceiveData(USART1);
}

// DMA Configuration for memory-to-memory transfer with Interrupts
void DMA_M2M_Interrupt_Init(DMA_Channel_TypeDef* DMA_CHx, uint32_t src, uint32_t dst, uint32_t ilen)
{
    DMA_InitTypeDef DMA_InitStruct;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE); // Enable DMA1 clock

    DMA_DeInit(DMA_CHx); // Deinitialize DMA channel (e.g., DMA1_Channel1)

    DMA_InitStruct.DMA_PeripheralBaseAddr = src;
    DMA_InitStruct.DMA_MemoryBaseAddr = dst;
    DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralSRC; // For M2M, "Peripheral" is the source
    DMA_InitStruct.DMA_BufferSize = ilen;
    DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Enable;
    DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
    DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
    DMA_InitStruct.DMA_Mode = DMA_Mode_Normal; // Single transfer
    DMA_InitStruct.DMA_Priority = DMA_Priority_High;
    DMA_InitStruct.DMA_M2M = DMA_M2M_Enable; // Enable Memory to Memory mode
    DMA_Init(DMA_CHx, &DMA_InitStruct);

    // Enable DMA Transfer Complete and Transfer Error interrupts for the channel
    DMA_ITConfig(DMA_CHx, DMA_IT_TC | DMA_IT_TE, ENABLE);
}

// NVIC Configuration for DMA1 Channel 1 Interrupt
void DMA1_Channel1_NVIC_Init(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); // Ensure this matches system's group config

    NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; // Example: Highest preemption priority
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;        // Example: Highest sub-priority
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

// DMA1 Channel 1 Interrupt Service Routine
void DMA1_Channel1_IRQHandler(void)
{
    // Check for Transfer Complete interrupt on Channel 1
    if (DMA_GetITStatus(DMA1_IT_TC1) != RESET)
    {
        // extern volatile uint8_t dma_transfer_status; // If using a global flag
        // dma_transfer_status = 1; // Indicate completion

        Show_Message(); // Send completion message and data

        // Optional: Disable DMA channel or further interrupts if only one transfer is needed
        // DMA_Cmd(DMA1_Channel1, DISABLE);
        // DMA_ITConfig(DMA1_Channel1, DMA_IT_TC | DMA_IT_TE, DISABLE);

        DMA_ClearITPendingBit(DMA1_IT_TC1); // IMPORTANT: Clear the interrupt pending bit
    }
    // Check for Transfer Error interrupt on Channel 1
    else if (DMA_GetITStatus(DMA1_IT_TE1) != RESET)
    {
        // extern volatile uint8_t dma_transfer_status; // If using a global flag
        // dma_transfer_status = 2; // Indicate error

        printf("!!! DMA Transfer Error on Channel 1 (from ISR) !!!\n");

        DMA_ClearITPendingBit(DMA1_IT_TE1); // IMPORTANT: Clear the interrupt pending bit
    }
    // Potentially check for other flags like HTIF if enabled (DMA1_IT_HT1)
}


// Show message after DMA transfer completion (called from ISR)
void Show_Message(void)
{
    printf("--- M2M DMA Transfer Complete (from ISR) ---\n");
    for (int i = 0; i < 10; i++)
    {
        printf("dstbuffer[%d] = 0x%02X (%u)\n", i, (unsigned int)dstbuffer[i], (unsigned int)dstbuffer[i]);
    }
    printf("--------------------------------------------\n");
}