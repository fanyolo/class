#include "stm32f10x.h"

void SysTick_Initialization(uint32_t delay, uint8_t priority);
void GPIOB_Initialization(void);
void GPIOA_Initialization(void);
void NVIC_Initialization(void);
void EXTI_Initialization(void);
void EXTI0_IRQHandler(void);
void SysTick_Handler(void);

volatile uint8_t mode = 0;  // ?????????
volatile uint8_t i = 0;     // ???? LED ????
volatile uint8_t j = 0;     // ???,??????

// ???????
const unsigned int Mode1[8] = {0x01, 0x02, 0x20, 0x03, 0x21, 0x22, 0x23, 0x00};
const unsigned int Mode2[8] = {0x01, 0x02, 0x20, 0x02, 0x01, 0x00, 0x23, 0x00};
const unsigned int Mode3[8] = {0x01, 0x02, 0x03, 0x23, 0x22, 0x21, 0x20, 0x00};

int main(void)
{
    SysTick_Initialization(100, 15);  // ?? 0.1s,??? 15
    GPIOB_Initialization();
    GPIOA_Initialization();
    NVIC_Initialization();
    EXTI_Initialization();

    while(1);
}

// **GPIOB ??(???)**
void GPIOB_Initialization(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_5;	  
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}

// **GPIOA ??(?? K1)**
void GPIOA_Initialization(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;			
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;	  
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

// **NVIC ??**
void NVIC_Initialization(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;  
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 

    // EXTI0 (PA0 ????)
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1; 
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

// **EXTI ??(PA0 ??????)**
void EXTI_Initialization(void)
{
    EXTI_InitTypeDef EXTI_InitStructure;
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0); 

    EXTI_InitStructure.EXTI_Line = EXTI_Line0;  		
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;		  
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;  
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;	 				 
    EXTI_Init(&EXTI_InitStructure);	
}

// **SysTick ??**
void SysTick_Initialization(uint32_t delay, uint8_t priority)
{
    SysTick->CTRL = 0;	
    SysTick->LOAD = (72000) * delay;  // 1ms = 72,000 ???
    SysTick->VAL = 0;

    // ?????
    SCB->SHP[11] &= 0x0F;
    SCB->SHP[11] |= (priority << 4);

    SysTick->CTRL = 0x07;  // ?? SysTick ??
}

// **SysTick ???????(?????)**
void SysTick_Handler(void)
{
    SCB->ICSR |= 1 << 25;   // ??????

    j++;
    if(j == 5)  // ? 0.5s ???? LED
    {
        switch(mode)
        {
            case 0: GPIOB->ODR = ~(Mode1[i]); break;
            case 1: GPIOB->ODR = ~(Mode2[i]); break;
            case 2: GPIOB->ODR = ~(Mode3[i]); break;
        }
        
        j = 0;
        i++;
        if(i > 7) i = 0;  // ????
    }
}

// **???? 0(PA0 ??????)**
void EXTI0_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line0) != RESET) 
    {
        mode++;
        if(mode > 2) mode = 0;  // ??????
        EXTI_ClearITPendingBit(EXTI_Line0);  // ??????
    }    
}


