#include "stm32f10x.h"
#include "BSP_LCD.h"
#include "BSP_USART1.h"

#define MAX_CHAR_COUNT 10

char received_chars[MAX_CHAR_COUNT];
int char_index = 0;

void USART1_IRQHandler(void) {
    if (USART1->SR & USART_SR_RXNE) {
        char received_char = USART1->DR;

        if (char_index < MAX_CHAR_COUNT) {
            received_chars[char_index++] = received_char;
        }

        if (char_index == MAX_CHAR_COUNT) {
           LcdFill(0, 0, 240, 320, WHITE); // 清屏
            char_index = 0;
        }

        // 逐字符显示在第4行（32*24字体）
        for (int i = 0; i < char_index; i++) {
            LcdDispEncharString(i * 24, 80, &received_chars[i], 3224, BLUE, WHITE);
        }
    }
}

int main(void) {
    USART1Init(9600);
    Show_Message(9600);

    LCD_Init();
    LCD_ScanDir(6); // 设置竖屏方向
    LcdFill(0, 0, 240, 320, WHITE); // 清屏

    

    while (1){
    LcdDispEncharString(0, 0, "Electronic Information", 1608, BLUE, WHITE);
    LcdDispEncharString(0, 16, "8207230322", 2416, RED, WHITE);
    LcdDispHanziString(0, 48, 3, 0, BLUE, WHITE);
	};
}
