#ifndef __MCO_H
#define __MCO_H

#include "stm32f10x.h"

void SYSCLK_Config_72MHz(void);
void SYSCLK_Config_36MHz(void);
void MCO_Init(uint8_t RCC_MCO_Source);

#endif
