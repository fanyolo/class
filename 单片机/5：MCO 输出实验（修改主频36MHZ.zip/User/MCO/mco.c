#include "mco.h"

/**
  * @brief  配置系统时钟为 72MHz（HSE=8MHz × PLL x9）。
  *         HCLK = 72MHz，PCLK1 = 36MHz，PCLK2 = 72MHz。
  */
void SYSCLK_Config_72MHz(void)
{
    ErrorStatus HSEStartUpStatus;

    RCC_DeInit();                             // 复位 RCC 寄存器
    RCC_HSEConfig(RCC_HSE_ON);                // 使能外部高速晶振 HSE
    HSEStartUpStatus = RCC_WaitForHSEStartUp(); // 等待 HSE 稳定

    if (HSEStartUpStatus == SUCCESS)
    {
        FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable); // 使能预取指缓存
        FLASH_SetLatency(FLASH_Latency_2);                    // 设置 Flash 等待周期：2 周期

        RCC_HCLKConfig(RCC_SYSCLK_Div1);  // AHB = SYSCLK = 72MHz
        RCC_PCLK2Config(RCC_HCLK_Div1);   // APB2 = HCLK = 72MHz
        RCC_PCLK1Config(RCC_HCLK_Div2);   // APB1 = HCLK/2 = 36MHz（最大限制）

        RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9); // PLL 输入为 HSE，倍频 9 倍
        RCC_PLLCmd(ENABLE);                                  // 启动 PLL
        while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET); // 等待 PLL 锁定

        RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);           // 选择 PLL 为系统时钟
        while (RCC_GetSYSCLKSource() != 0x08);               // 确认 PLL 成为系统时钟源
    }
    else
    {
        while (1); // 若 HSE 启动失败，则停机
    }
}

/**
  * @brief  配置系统时钟为 36MHz（HSE=8MHz ÷2 ×9）。
  *         HCLK = 36MHz，PCLK1 = 36MHz，PCLK2 = 36MHz。
  */
void SYSCLK_Config_36MHz(void)
{
    ErrorStatus HSEStartUpStatus;

    RCC_DeInit();                             // 复位 RCC 寄存器
    RCC_HSEConfig(RCC_HSE_ON);                // 使能 HSE
    HSEStartUpStatus = RCC_WaitForHSEStartUp(); // 等待 HSE 稳定

    if (HSEStartUpStatus == SUCCESS)
    {
        FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable); // 使能预取指缓存
        FLASH_SetLatency(FLASH_Latency_1);                    // 设置 Flash 等待周期：1 周期

        RCC_HCLKConfig(RCC_SYSCLK_Div1);  // AHB = SYSCLK = 36MHz
        RCC_PCLK2Config(RCC_HCLK_Div1);   // APB2 = HCLK = 36MHz
        RCC_PCLK1Config(RCC_HCLK_Div1);   // APB1 = HCLK = 36MHz

        RCC_PLLConfig(RCC_PLLSource_HSE_Div2, RCC_PLLMul_9); // PLL 输入为 HSE/2，倍频 9 倍
        RCC_PLLCmd(ENABLE);                                  // 启动 PLL
        while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET); // 等待 PLL 锁定

        RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);           // 选择 PLL 为系统时钟
        while (RCC_GetSYSCLKSource() != 0x08);               // 确认 PLL 成为系统时钟源
    }
    else
    {
        while (1); // 若 HSE 启动失败，则停机
    }
}

/**
  * @brief  初始化 GPIOA.8 为 MCO 输出，并设置 MCO 时钟源。
  * @param  RCC_MCO_Source: 要输出的时钟源，可选 SYSCLK、HSI、HSE、PLL/2。
  */
void MCO_Init(uint8_t RCC_MCO_Source)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); // 使能 GPIOA 时钟

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;     // 设置输出速率为 50MHz
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;       // 复用推挽输出模式
    GPIO_Init(GPIOA, &GPIO_InitStructure);                // 初始化 GPIOA.8

    RCC_MCOConfig(RCC_MCO_Source);                        // 配置 MCO 时钟源
}
