#include "mco.h"

int main(void)
{
    // 实验内容 (1): 系统时钟为 72MHz，观察 MCO 输出五种时钟源
    // SYSCLK_Config_72MHz();
    // MCO_Init(RCC_MCO_SYSCLK);
    // MCO_Init(RCC_MCO_HSI);
    // MCO_Init(RCC_MCO_HSE);
    // MCO_Init(RCC_MCO_PLLCLK_Div2);
    // MCO_Init(RCC_MCO_NoClock);

    // 实验内容 (2): 系统时钟为 36MHz，从 MCO 输出 SYSCLK
    SYSCLK_Config_36MHz();
    MCO_Init(RCC_MCO_SYSCLK);

    while (1);
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
    while (1);
}
#endif
