#ifndef __BSP_DELAY_H
#define __BSP_DELAY_H

void delay_qus(void);
void delay_us(uint16_t us);
void delay_ms(uint16_t ms);

#endif





