#ifndef __BSP_LED_H
#define __BSP_LED_H

#include "stm32f10x.h"
#include "BSP_BITBAND.h"

#define LED_GREEN PB_OUT(0)
#define LED_BLUE PB_OUT(1)  
#define LED_RED PB_OUT(5) 

void LED_Init(void);



#endif
