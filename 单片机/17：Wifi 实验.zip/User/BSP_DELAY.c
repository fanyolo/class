#include "stm32f10x.h"

/* 1/4微秒延时函数(含函数调用及返回时间共计耗时约1/4微秒, 72MHz主频)  */
void delay_qus(void)
{
__ASM("nop");
__ASM("nop");
__ASM("nop");
__ASM("nop");
__ASM("nop");
__ASM("nop");
__ASM("nop");
__ASM("nop");
}


/* 微秒延时函数，us-延时时间 */
void delay_us(uint16_t us)
{
while(us--)
{
delay_qus( );
delay_qus( );
delay_qus( );
delay_qus( );
}
}


/* 毫秒延时函数，ns-延时时间 */
void delay_ms(uint16_t ms)
{
while(ms--)
{
delay_us(1000);
}
}


