//  ����ͨ��     USART3    

#ifndef __BSP_USART3_H
#define __BSP_USART3_H

#include <stdio.h>     
// ʹ��printf��scanf��getchar�Ⱥ���
//  Keil ����C/C++�й�ѡ"Use MicroLIB"

#include "stm32f10x.h"

extern uint8_t ReceiveData;
extern uint8_t ReceiveFlag;
extern int LED_mode;

void USART3_IOInit(void);
void NVIC_USART3Enable(void);
void USART3_Init(uint32_t BAUDRATE);
void USART3_IRQHandler(void);
void USART1_IOInit(void);
void NVIC_USART1Enable(void);
void USART1Init(uint32_t BAUDRATE);


int fputc(int ch, FILE *f);
int fgetc(FILE *f);


#endif


