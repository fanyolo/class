#ifndef  __BSP_WIFI_H
#define  __BSP_WIFI_H

#include "BSP_USART3.h"
#include "BSP_DELAY.h"

void WIFI_Init(void);

#endif
