////  TIM3_CH4��ӦPB1�� PWM
//#include "stm32f10x.h"
//void TIM3_Initialization(uint16_t ARR_VAL,uint16_t PSC_VAL,uint16_t CCR_VAL);
//void GPIOB_Initialization(void);	

//int main(void)
//{
//GPIOB_Initialization();
////(uint16_t ARR_VAL,uint16_t PSC_VAL,uint16_t CCR_VAL)
//// TIM_OCPolarity_High, PWM1:  q = (1 - CCR_VAL) / ARR_VAL
//// TIM_OCPolarity_High, PWM2:  q = CCR_VAL) / ARR_VAL
//// TIM_OCPolarity_Low,  PWM1:  q = CCR_VAL) / ARR_VAL
//// TIM_OCPolarity_Low,  PWM2:  (1 - CCR_VAL) / ARR_VAL
//TIM3_Initialization(100,7200,80);

//while(1);
//}

//void GPIOB_Initialization(void)
//{
//GPIO_InitTypeDef GPIO_InitStructure;
//RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);	
//GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;	  
//GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
//GPIO_Init(GPIOB, &GPIO_InitStructure);
//}

////PWM��ʱ�Ƚ������ʼ������ʵ��
//void TIM3_Initialization(uint16_t ARR_VAL,uint16_t PSC_VAL,uint16_t CCR_VAL)
//{
//RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);	
//	
//TIM_TimeBaseInitTypeDef  TIM_TimeBaseStruct;
////��λTIM3 ����ʼ״̬
//TIM_DeInit(TIM3);
////��ʱ��TIM3��ʼ��
////��������һ�������¼�����ʱװ�����Զ���װ�ؼĴ���������ֵ
//TIM_TimeBaseStruct.TIM_Period = ARR_VAL - 1;
////����CNT�������ļ���ʱ��Ԥ��Ƶֵ
//TIM_TimeBaseStruct.TIM_Prescaler = PSC_VAL - 1;
////����TIM����ģʽ�����ϼ���ģʽ
//TIM_TimeBaseStruct.TIM_CounterMode = TIM_CounterMode_Up;
////���������˲���Ԫ�Ĳ���ʱ��Ƶ�ʣ�ʱ�ӷָ�:TDTS = Tck_tim
////��Ҫ�������˲�ͨ���ϣ���Ӧ��ʱ���õ�Timer��������
//TIM_TimeBaseStruct.TIM_ClockDivision = TIM_CKD_DIV1;
////�ظ���������
//TIM_TimeBaseStruct.TIM_RepetitionCounter = 0;
////����ָ���Ĳ�����ʼ��TIMx��ʱ�������λ
//TIM_TimeBaseInit(TIM3,&TIM_TimeBaseStruct);

//TIM_OCInitTypeDef   TIM_OCInitStruct;

////��ʼ��TIM3�Ƚ����ģʽ��PWM1
//TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;
////TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM2;
////�������:TIM����Ƚϼ��Ը�
//TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;
//// TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_Low;
////�Ƚ����ʹ��
// TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
////���ô�װ�벶��ȽϼĴ���������ֵ����ʼ��ͨ��4
//TIM_OCInitStruct.TIM_Pulse = CCR_VAL; 
//TIM_OC4Init(TIM3,&TIM_OCInitStruct);
//	
////ʹ��TIM3
//TIM_Cmd(TIM3,ENABLE);
//}

#include "stm32f10x.h"

void TIM3_Initialization(uint16_t ARR_VAL, uint16_t PSC_VAL, uint16_t CCR_VAL);
void TIM1_Initialization(void);
void GPIO_Initialization(void);
void TIM1_UP_IRQHandler(void);

uint16_t dutyCycle = 80;  // 初始占空比
uint16_t ARR_VAL = 100;   // PWM 计数周期

int main(void)
{
    GPIO_Initialization();
    TIM3_Initialization(ARR_VAL, 7200, dutyCycle);
    TIM1_Initialization();

    while (1);
}

// GPIO 初始化（PB1 PWM 输出 + 按键输入）
void GPIO_Initialization(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    // PWM 输出（PB1, TIM3_CH4）
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // KEY1 (PA0) - 上拉输入
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // KEY2 (PC13) - 上拉输入
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
}

// PWM 输出初始化
void TIM3_Initialization(uint16_t ARR_VAL, uint16_t PSC_VAL, uint16_t CCR_VAL)
{
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

    TIM_TimeBaseInitTypeDef TIM_TimeBaseStruct;
    TIM_OCInitTypeDef TIM_OCInitStruct;

    TIM_DeInit(TIM3);

    // 配置 TIM3 计数周期
    TIM_TimeBaseStruct.TIM_Period = ARR_VAL - 1;
    TIM_TimeBaseStruct.TIM_Prescaler = PSC_VAL - 1;
    TIM_TimeBaseStruct.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStruct);

    // 配置 PWM 模式
    TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStruct.TIM_Pulse = CCR_VAL;
    TIM_OC4Init(TIM3, &TIM_OCInitStruct);

    TIM_Cmd(TIM3, ENABLE);
}

// TIM1 用于定时扫描按键
void TIM1_Initialization(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStruct;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);

    TIM_TimeBaseStruct.TIM_Period = 10000 - 1;  // 10ms 扫描
    TIM_TimeBaseStruct.TIM_Prescaler = 7200 - 1;
    TIM_TimeBaseStruct.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStruct);

    TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    TIM_Cmd(TIM1, ENABLE);
}

// TIM1 定时中断服务程序（按键扫描）
void TIM1_UP_IRQHandler(void)
{
    static uint8_t key1_last = 1, key2_last = 1;

    if (TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
    {
        TIM_ClearITPendingBit(TIM1, TIM_IT_Update);

        uint8_t key1_now = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0);
        uint8_t key2_now = GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13);

        // KEY1 增加占空比
        if (key1_last == 1 && key1_now == 0)
        {
            if (dutyCycle < 90) dutyCycle += 10;
            TIM3->CCR4 = (dutyCycle * ARR_VAL) / 100;
        }
        key1_last = key1_now;

        // KEY2 减少占空比
        if (key2_last == 1 && key2_now == 0)
        {
            if (dutyCycle > 10) dutyCycle -= 10;
            TIM3->CCR4 = (dutyCycle * ARR_VAL) / 100;
        }
        key2_last = key2_now;
    }
}



