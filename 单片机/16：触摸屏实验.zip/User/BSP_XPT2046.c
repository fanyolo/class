// BSP_XPT2046.c 驱动文件程序源码

#include "BSP_XPT2046.h"
#include "BSP_LCD.h"
#include "stdlib.h"
#include "math.h"


sCaliParam CaliParam;
uint8_t DFR_READ_X=0XD0;       //差分方式读x坐标 适合竖屏
uint8_t DFR_READ_Y=0X90;        //差分方式读y坐标 适合竖屏
float XPT2046_Kx;
float XPT2046_Ky;
int XPT2046_Dx;
int XPT2046_Dy;

extern void TouchAction(uint8_t act,uint16_t x,uint16_t y);

/*XPT2046写命令；dat-控制命令字*/
void XPT2046WriteCmd(uint8_t cmd)
{
uint8_t i;
for(i=0;i<8;i++)                //循环将8bit数据输出到总线上
{
XPT2046_CLK = 0;             //先拉低时钟
XPT2046_DIN = (cmd&0x80)?1:0;    //将最高位的值输出到XPT2046_DIN上
delay_us(1);                      //延时1us等待数据锁存
XPT2046_CLK = 1;             //然后拉高，完成一位操作
cmd <<=1;        //左移将次高位变为最高位，实现高位在先低位在后的发送顺序
}
}


/*XPT2046读数据；返回值-读到的数据*/
uint16_t XPT2046ReadDat(void)
{
uint8_t i;
uint16_t dat =0;
for(i=0; i<16; i++)        //循环将总线上的16bit数据读入dat中
{
dat <<=1;      //左移将己读到的位向高位移动，实现高位在前低位在后的接收顺序
XPT2046_CLK=0;        //先拉低时钟
if(XPT2046_DOUT != 0)        //读取XPT2046_DOUT引脚的值到dat最低位上
{
dat |= 0x01;
}
XPT2046_CLK = 1;     //再拉高时钟，完成一个位的操作
}
dat <<= 1;    //移除BUSY位数据
dat >>= 4;    //剩余数据只有高12位有效

return dat;     //最后返回读到的字节数据
}



/*获取一次转换结果；cmd-控制命令字，返回值-转换结果*/
uint16_t XPT2046SingleRead(uint8_t cmd)
{
uint16_t value;

XPT2046_CLK =0;      //先拉低CLK引脚

XPT2046_CS =0;        //使能片选

XPT2046WriteCmd(cmd);      //发送控制命令

value=XPT2046ReadDat();     //读取转换结果 

XPT2046_CS =1;      //失能片选

return value;         //返回一次转换结果
}


/*采用中位值平均滤波法获取转换结果；返回值；temp-滤波后的逻辑坐标*/
int XPT2046FilterRead(uint8_t cmd)
{
uint8_t i, j;
uint16_t buf[5];
uint16_t temp,sum;

for(i=0; i<5; i++)          //连续获取5次转换结果
{
buf[i]=XPT2046SingleRead(cmd);
}
for(i=0; i<4; i++)      //对5次转换结果进行升序排列
  {
   for(j=i+1; j<5; j++)
     {
    if(buf[i]>buf[j])
       {
      temp = buf[i];
      buf[i] = buf[j];
      buf[j] = temp;
       }
     }
   }
sum = 0;
temp = 0;
for(i=1; i<4; i++)     //分别舍弃1个最低和1个最高数据，并对剩余数据求和
{
sum += buf[i];
}
temp = sum /3;   //对采集的数据求平均
return temp;       //返回滤波后的数据
}

/*获取触摸逻辑坐标；*LogicX,*LogicY-X,Y的逻辑坐标；返回值-0:失败，1:成功*/
int GetLogicCoord(uint16_t *LogicX,uint16_t *LogicY)
{
uint16_t xPos1,xPos2,yPosl,yPos2;

xPos1 = XPT2046FilterRead(DFR_READ_X);    //获取第一次触摸的X坐标
yPosl = XPT2046FilterRead(DFR_READ_Y);   //获取第一次触摸的Y坐标
xPos2 = XPT2046FilterRead(DFR_READ_X);   //获取第二次触摸的X坐标
yPos2 = XPT2046FilterRead(DFR_READ_Y);    //获取第二次触摸的Y坐标
if(xPos1<TOUCH_THRESHOLD || yPosl<TOUCH_THRESHOLD)    //舍弃无效数据
{
return 0;
}

//两次按下的偏差较大，忽略
if(abs(xPos1- xPos2) > TOUCH_DIFF || abs(yPosl-yPos2) > TOUCH_DIFF)
{
return 0;
}

*LogicX=xPos1;     //获取当前触摸点所在X轴的逻辑坐标
*LogicY=yPosl;     //获取当前触摸点所在Y轴的逻辑坐标
return 1;
}


/*获取触摸坐标坐标*/
void GetCoord(uint16_t *x,uint16_t *y)
{
uint16_t LogicX, LogicY;



if(GetLogicCoord(&LogicX, &LogicY) != 0)
{

/*    竖屏, 某次测试的数据,  使用一段时间后调用校准函数获取数据来更新   */
CaliParam.Kx = 0.065596;
CaliParam.Ky = -0.091743;
CaliParam.Dx = -12;
CaliParam.Dy = 337;

*x =CaliParam.Kx*LogicX+CaliParam.Dx;//计算当前触摸点所在X轴物理坐标
*y =CaliParam.Ky *LogicY+CaliParam.Dy;//计算当前触摸点所在Y轴物理坐标
}
}


void LcdClear(uint16_t Color)
{
LcdFill(0,0,240,320,Color);    // 竖屏：240-320
}


/*画一个3*3的校准点*/
void DrawTouchPoint(uint16_t x,uint16_t y)
{
LcdFill(x-1,y-1,3,3,RED);    
}


/*画一个2*2的点*/
void DrawBigPoint(uint8_t x,uint16_t y,uint16_t Color)
{
LcdFill(x,y,2,2,Color);    
}


/*计算两个坐标点的距离*/
uint16_t GetDistance(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2)
{
uint16_t dist;
uint32_t s1,s2;
s1 = abs(x1-x2);
s2 = abs(y1-y2);
s1 *= s1;
s2 *= s2;
dist = sqrt(s1+s2);
return dist;
}


/*电阻式触摸屏校准*/
void TouchAdjust(void)
{
uint8_t cnt =0;
	
//  竖屏: 240-320
uint16_t  LcdWidth = 240;
uint16_t  LcdHeight = 320;
int d1,d2;
int disp;
int Pos[5][2];    //暂存校准点逻辑坐标

LcdClear(WHITE);    //清屏

if(LcdWidth==320)      //横屏模式，X,Y轴交换
{
DFR_READ_X=0X90;
DFR_READ_Y=0XD0;
}

DrawTouchPoint(20,20);//在左上角画一个校准标志

while(1)
{
if(XPT2046_PEN == 0)      //按键按下了
{
Pos[cnt][0]=XPT2046FilterRead(DFR_READ_X);  //获取触摸点所在x轴的逻辑坐标
Pos[cnt][1]=XPT2046FilterRead(DFR_READ_Y);   //获取触摸点所在y轴的逻辑坐标
cnt++;
while(XPT2046_PEN !=1);
switch(cnt)
{
case 1:
LcdFill(0,0,40,40,WHITE);       //清除左上角校准标志
DrawTouchPoint(LcdWidth-20,20);  //在右上角画一个校准标志
break;

case 2:
LcdFill(LcdWidth-40,0,LcdWidth,40,WHITE);     //清除右上角校准标志
DrawTouchPoint(20,LcdHeight-20);           //在左下角画一个校准标志
break;

case 3:
LcdFill(0,LcdHeight-40,40,LcdHeight,WHITE);      //清除左下角校准标志
DrawTouchPoint(LcdWidth-20,LcdHeight-20);    //在右下角画一个校准标志
break;

case 4:
LcdFill(LcdWidth-40,LcdHeight-40,LcdWidth,LcdHeight,WHITE);   //清除右下角校准标志
DrawTouchPoint(LcdWidth/2,LcdHeight/2);    //在中心画一个校准标志
break;

case 5:
d1=GetDistance(Pos[0][0],Pos[0][1],Pos[1][0],Pos[1][1]);     // d1-S1
d2 =GetDistance(Pos[2][0],Pos[2][1],Pos[3][0],Pos[3][1]);    // d2-S2
disp=abs(d1-d2);
if(disp>50 || d1==0 || d2==0)     //不合格
{
cnt = 0;
LcdClear(WHITE);     //清屏为白色
DrawTouchPoint(20,20);    //在左上角画出校准标志
continue;                  //返回，重新校准
}

d1=GetDistance(Pos[0][0],Pos[0][1],Pos[2][0],Pos[2][1]);     // d1-S3
d2=GetDistance(Pos[1][0],Pos[1][1],Pos[3][0],Pos[3][1]);     // d2-S4
disp=abs(d1 - d2);
if(disp>50 || d1==0 || d2==0)    //不合格
{
cnt =0;
LcdClear(WHITE);      //清屏为白色
DrawTouchPoint(20,20);    //在左上角画出校准标志
continue;           //返回，重新校准
}

d1 =GetDistance(Pos[0][0],Pos[0][1],Pos[3][0],Pos[3][1]);    // d1-S5
d2=GetDistance(Pos[1][0],Pos[1][1],Pos[2][0],Pos[2][1]);     // d2-S6
disp=abs(d1-d2);
if(disp>50 || d1==0 || d2 == 0)   //不合格
{
cnt =0;
LcdClear(WHITE);    //清屏为白色
DrawTouchPoint(20,20);     //在左上角画出校准标志
continue;     //返回，重新校准
}

CaliParam.Kx =((float)(LcdWidth-40)/(Pos[1][0]-Pos[0][0])+
                    (float)(LcdWidth-40)/(Pos[3][0]-Pos[2][0]))/2;     //计算X轴上的比例因子
CaliParam.Ky =((float)(LcdHeight-40)/(Pos[2][1]-Pos[0][1])+
                     (float)(LcdHeight-40)/(Pos[3][1]-Pos[1][1]))/2;    //计算Y轴上的比例因子
//计算X轴上偏差常数
CaliParam.Dx =(LcdWidth - CaliParam.Kx*(Pos[1][0]+Pos[0][0]))/2;
//计算Y轴上偏差常数
CaliParam.Dy =(LcdHeight -CaliParam.Ky*(Pos[2][1]+Pos[0][1]))/2;
//计算X轴上的缩进量，中心点
d1=abs((int)(CaliParam.Kx*Pos[4][0])+CaliParam.Dx-LcdWidth/2);  
//计算Y轴上的缩进量,   中心点
d2=abs((int)(CaliParam.Ky*Pos[4][1])+CaliParam.Dy -LcdHeight/2);
if(d1>10 || d2>10)
{
cnt =0;
LcdClear(WHITE);     //清屏为白色
DrawTouchPoint(20,20);    //在左上角画出校准标志
continue;    //返回，重新校准
}

LcdClear(WHITE);    //清屏为白色
// void LcdDispEncharString(uint16_t X, uint16_t Y,char* pstr,uint16_t MODE,uint16_t TextColor, uint16_t BackColor);
LcdDispEncharString(35, 110,"Touch Screen Adjust OK!",1608,BLUE, WHITE);
printf("Touch Screen Adjust OK!\n");

XPT2046_Kx = CaliParam.Kx;
XPT2046_Ky = CaliParam.Ky;
XPT2046_Dx = CaliParam.Dx;
XPT2046_Dy = CaliParam.Dy;

delay_ms(1000);
LcdClear(WHITE);     //清屏为白色

return;
}
}
}
}


/*触摸屏驱动函数，检测触摸事件，调用相应动作函数*/
void TouchDriver(void)
{
static uint16_t xLast =0;
static uint16_t yLast =0;
static uint8_t PENLast =1;  //触摸状态标志位，保存上一次的状态
uint16_t xPos,yPos;

if(XPT2046_PEN==0 && PENLast==1)    //按下事件
{
PENLast =XPT2046_PEN;
GetCoord(&xPos,&yPos);
TouchAction(ACTION_DOWN,xPos,yPos);
xLast = xPos;
yLast = yPos;
}


if(XPT2046_PEN ==0)    //滑动事件
{
GetCoord(&xPos,&yPos);
if(xPos != xLast || yPos != yLast)     //检测触摸屏滑动动作
{
TouchAction(ACTION_MOVE,xPos,yPos);
}
xLast =xPos;
yLast =yPos;
}

if(XPT2046_PEN ==1 && PENLast == 0)//抬起事件
{
PENLast = XPT2046_PEN;
TouchAction(ACTION_UP,xLast,yLast);
}
}


/*XPT2046引脚初始化*/
void XPT2046IOInit(void)
{
GPIO_InitTypeDef GPIO_InitStructure;
RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE | RCC_APB2Periph_AFIO,ENABLE);
//使能GPIOD、E端口及复用端口时钟
GPIO_InitStructure.GPIO_Pin =GPIO_Pin_13; //设置XPT2046_CS片选引脚->PD13
GPIO_InitStructure.GPIO_Mode =GPIO_Mode_Out_PP; //设置为通用推挽输出
GPIO_InitStructure.GPIO_Speed =GPIO_Speed_50MHz;//设置输出速率50MHz
GPIO_Init(GPIOD,&GPIO_InitStructure);    
GPIO_SetBits(GPIOD,GPIO_Pin_13);    //设置PD13为高，失能片选

//设置SCK引脚->PE0,   XPT2046_DIN引脚->PE2
GPIO_InitStructure.GPIO_Pin =GPIO_Pin_0 | GPIO_Pin_2;
GPIO_InitStructure.GPIO_Mode =GPIO_Mode_Out_PP;  //设置为通用推挽输出
GPIO_InitStructure.GPIO_Speed =GPIO_Speed_50MHz;  //设置输出速率为50MHz
GPIO_Init(GPIOE,&GPIO_InitStructure); 
GPIO_SetBits(GPIOE,GPIO_Pin_0 | GPIO_Pin_2);  
 
//初始化XPT2046_DOUT引脚->PE3, XPT2046_PEN引脚->PE4
GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4;    
GPIO_InitStructure.GPIO_Mode =GPIO_Mode_IPU;      //设置为上拉输入
GPIO_Init(GPIOB,&GPIO_InitStructure);                       
}

/*触摸初始化函数*/
void TouchInit(void)
{
XPT2046IOInit();
/*   使用一段时间后调用校准函数   */
//   TouchAdjust( );  
}




