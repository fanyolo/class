#ifndef __TOUCH_H
#define __TOUCH_H

#include "BSP_BITBAND.h"
#include "BSP_DELAY.h"
#include "BSP_USART1.h"

extern float XPT2046_Kx;
extern float XPT2046_Ky;
extern int XPT2046_Dx;
extern int XPT2046_Dy;

#define TOUCH_THRESHOLD 20 //触摸坐标阈值

#define TOUCH_DIFF  10      //两次触摸差值

#define ACTION_DOWN  1   //按下事件标志位

#define ACTION_MOVE  3     //移动事件标志位

#define ACTION_UP  2          //抬起事件标志位

#define CALI_PARAM_ADDR 0xE0     //校验值在EEPROM中的存储地址

typedef struct
{
float Kx;      //X轴上的比例因子
  
float Ky;      //Y轴上的比例因子

int Dx;        //X轴上的偏移量

int Dy;        //Y轴上的偏移量

}sCaliParam;


#define XPT2046_CS PD_OUT(13)    //片选

#define XPT2046_CLK PE_OUT(0)     //时钟信号

#define XPT2046_DIN PE_OUT(2)     //接XPT2046 DIN引脚

#define XPT2046_DOUT PE_IN(3)     //接XPT2046 DOU引脚

#define XPT2046_PEN PE_IN(4)     //接中断信号线



void TouchDriver(void);

void TouchInit(void);

void LcdClear(uint16_t Color);


#endif





