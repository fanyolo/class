#include "stm32f10x.h"
#include "BSP_LCD.h"
#include "BSP_USART1.h"
#include "BSP_XPT2046.h"
#include <stdio.h> // 用于 printf 和 sprintf
#include <string.h> // 用于 strlen (可选，用于精确文本居中)

// 虚拟按钮的配置
#define NUM_BUTTONS 10
#define BUTTON_COLS 5
#define BUTTON_ROWS 2

// 定义虚拟按钮的结构体
typedef struct {
    uint16_t x;             // 左上角 X 坐标
    uint16_t y;             // 左上角 Y 坐标
    uint16_t width;         // 按钮宽度
    uint16_t height;        // 按钮高度
    char label[2];          // 按钮标签（例如 "0", "1"）
    uint8_t id;             // 按钮 ID (0-9)
    uint16_t color;         // 默认按钮颜色
    uint16_t pressed_color; // 按钮按下时的颜色
} VirtualButton;

// 存储所有按钮定义的数组
VirtualButton buttons[NUM_BUTTONS];

// 跟踪当前按下的按钮索引 (-1 表示没有按钮被按下)
static int8_t current_pressed_button_idx = -1;

// 绘制或重新绘制单个按钮的函数
void DrawButton(uint8_t button_idx, uint8_t is_pressed) {
    if (button_idx >= NUM_BUTTONS) return; // 安全检查

    VirtualButton btn = buttons[button_idx];
    uint16_t color_to_use = is_pressed ? btn.pressed_color : btn.color;

    // 填充按钮区域
    LcdFill(btn.x, btn.y, btn.width, btn.height, color_to_use);

   
    uint16_t text_x = btn.x + (btn.width / 2) - (strlen(btn.label) * 8 / 2);
    uint16_t text_y = btn.y + (btn.height / 2) - (16 / 2);
    LcdDispEncharString(text_x, text_y, btn.label, 1608, BLACK, color_to_use);
}

// 初始化所有虚拟按钮的布局和属性
void Init_VirtualButtons(void) {
    uint16_t screen_width = LCD_X_LENGTH;
    uint16_t screen_height = LCD_Y_LENGTH;

    // 按钮位于屏幕的下半部分
    uint16_t lower_half_y_start = screen_height / 2;
    uint16_t button_area_height = screen_height / 2;

    uint16_t button_width = screen_width / BUTTON_COLS;
    // 如果需要，可以在按钮之间添加小的间隙，例如通过稍微减小按钮宽度
    // button_width -= 2; // 示例间隙
    uint16_t button_height = button_area_height / BUTTON_ROWS;
    // button_height -= 2; // 示例间隙

    uint8_t i;
    for (i = 0; i < NUM_BUTTONS; ++i) {
        uint8_t row = i / BUTTON_COLS; // 第 0 行（0-4），第 1 行（5-9）
        uint8_t col = i % BUTTON_COLS; // 列索引（0 到 4）

        buttons[i].id = i;
        sprintf(buttons[i].label, "%d", i);

        buttons[i].width = button_width;
        buttons[i].height = button_height;
        // 如果添加了间隙，可以稍微调整偏移量
        buttons[i].x = col * button_width; // + (col * gap_x_pixels);
        buttons[i].y = lower_half_y_start + (row * button_height); // + (row * gap_y_pixels);

        buttons[i].color = GREY;         // 默认颜色 (0x8430)
        buttons[i].pressed_color = YELLOW; // 按下时的颜色 (0xFFE0)

        DrawButton(i, 0); // 在正常状态下绘制按钮（未按下状态）
    }
}

/*
 * TouchAction 函数
 * 当触摸事件发生时，TouchDriver 会调用此函数。
 * act: 触摸事件类型 (ACTION_DOWN, ACTION_MOVE, ACTION_UP)
 * x, y: 校准后的 LCD 坐标
 */
void TouchAction(uint8_t act, uint16_t x, uint16_t y) {
    uint8_t i;
    char display_str[3]; // 存储按键编号字符串的缓冲区（例如 "9" + null）

    switch (act) {
        case ACTION_DOWN:
            current_pressed_button_idx = -1; // 重置之前按下的按钮状态
            for (i = 0; i < NUM_BUTTONS; ++i) {
                // 检查触摸坐标是否在当前按钮的范围内
                if (x >= buttons[i].x && x < (buttons[i].x + buttons[i].width) &&
                    y >= buttons[i].y && y < (buttons[i].y + buttons[i].height)) {
                    current_pressed_button_idx = i;
                    DrawButton(i, 1); // 重新绘制按钮为按下状态
                    // printf("DBG: 按钮 %d 按下\n", i); // 通过串口调试输出
                    break; // 找到被按下的按钮
                }
            }
            break;

        case ACTION_MOVE:
            if (current_pressed_button_idx != -1) {
                // 获取当前按下的按钮
                VirtualButton btn = buttons[current_pressed_button_idx];
                // 检查触摸是否移动到按钮范围外
                if (!(x >= btn.x && x < (btn.x + btn.width) &&
                      y >= btn.y && y < (btn.y + btn.height))) {
                    // 触摸移动到外面，恢复按钮的正常状态并无效化按下
                    DrawButton(current_pressed_button_idx, 0);
                    current_pressed_button_idx = -1;
                    // printf("DBG: 移动到按钮外部\n"); // 通过串口调试输出
                }
            }
            break;

        case ACTION_UP:
            if (current_pressed_button_idx != -1) {
                // 按钮之前已被按下
                VirtualButton released_button = buttons[current_pressed_button_idx];

                // 可选：验证松开是否发生在同一个按钮范围内
                // 这是一种良好的做法，尽管如果 ACTION_MOVE 移动到外部，current_pressed_button_idx 应该已经是 -1。
                if (x >= released_button.x && x < (released_button.x + released_button.width) &&
                    y >= released_button.y && y < (released_button.y + released_button.height)) {

                    uint8_t key_val = released_button.id;

                 
                    printf("%d", key_val);

                    LcdFill(0, 0, LCD_X_LENGTH, LCD_Y_LENGTH / 2, WHITE);

                 
                    sprintf(display_str, "%d", key_val);
                    // 计算大致居中的位置
                    uint16_t text_display_x = (LCD_X_LENGTH / 2) - (strlen(display_str) * 8 / 2);
                    uint16_t text_display_y = (LCD_Y_LENGTH / 4) - (16 / 2); // 上半部分的垂直居中
                    LcdDispEncharString(text_display_x, text_display_y, display_str, 1608, BLACK, WHITE);

                    // 重新绘制按钮为正常状态（未按下状态）
                    DrawButton(current_pressed_button_idx, 0);
                    // printf("DBG: 按钮 %d 松开并执行操作！\n", key_val); // 通过串口调试输出
                } else {
                    // 如果松开发生在最初按下按钮范围之外，恢复按钮的视觉效果
                     DrawButton(current_pressed_button_idx, 0);
                }
            }
            // 重置按下按钮的索引以便下次触摸序列
            current_pressed_button_idx = -1;
            break;
    }
}

int main(void) {
    // 初始化 USART1 进行串口通信（例如用于调试或发送按键代码）
    USART1Init(9600);
    // Show_Message(9600); // 如果原代码中有这个函数，确保它已定义或根据需要删除。
                       // 它可能是一个自定义函数，用于打印启动信息。
    printf("串口初始化完成，波特率为 9600 bps。\n");

    // 初始化 LCD
    LCD_Init();
    LCD_ScanDir(6); // 设置扫描方向。重要：这会影响 LCD_X_LENGTH 和 LCD_Y_LENGTH 的解释。
                    // 如果 ScanDir(6) 结果是横屏（例如 320x240），那么 LCD_X_LENGTH 应该为 320。
    LcdClear(WHITE); // 清除 LCD 背景为白色

    // 初始化并绘制虚拟按钮
    Init_VirtualButtons();

    // 初始化触摸屏控制器（例如 XPT2046）
    TouchInit();

    printf("系统初始化完成。触摸按钮发送按键代码。\n");

    while (1) {
       
        TouchDriver();

       
    }
}
