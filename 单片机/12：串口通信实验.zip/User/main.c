#include <stdio.h>
#include "stm32f10x.h"

// ??????
const unsigned int Mode1[8] = {0x03, 0x21, 0x22, 0x23, 0x00};  // ??1(????? LED)
const unsigned int Mode2[8] = {0x02, 0x01, 0x00, 0x23, 0x00};  // ??2(?? LED ??)
const unsigned int Mode3[8] = {0x01, 0x02, 0x20, 0x03, 0x21, 0x22, 0x23, 0x00};  // ??3(LED ??)
const unsigned int Mode4[8] = {0x01, 0x02, 0x20, 0x02, 0x01, 0x00, 0x23, 0x00};  // ??4(LED ????)
const unsigned int Mode5[8] = {0x01, 0x02, 0x03, 0x23, 0x22, 0x21, 0x20, 0x00};  // ??5(LED ??)

// ????
volatile uint8_t mode = 0;  // ????
volatile uint8_t i = 0;     // LED ????
volatile uint8_t j = 0;     // ???,?????????

// ????

void GPIOB_Initialization(void);
void USART1Init(uint32_t BAUDRATE);
void NVIC_USART1Enable(void);
void USART1_IRQHandler(void);
void TIM3_Initialization(void);
void TIM3_IRQHandler(void);
void Show_Message(void);

int main(void)
{
    // ?????

    GPIOB_Initialization();             // ???GPIOB?
    USART1Init(9600);                   // ???USART1,???9600
    TIM3_Initialization();              // ???TIM3???

    while(1);  // ?????,??????
}

// **GPIOB ???**
void GPIOB_Initialization(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);  // ??GPIOB??
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_5;  // ??GPIOB?0, 1, 5?
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;  // ?????????
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}

// **USART1 ???**
void USART1Init(uint32_t BAUDRATE)
{
    USART_InitTypeDef USART_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); // ?? GPIOA ??
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE); // ?? USART1 ??

    // ??PA9?TX,PA10?RX
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;  // TX
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10; // RX
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // ??USART1
    USART_InitStructure.USART_BaudRate = BAUDRATE;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART1, &USART_InitStructure);
    NVIC_USART1Enable();  // ??USART1??
    USART_Cmd(USART1, ENABLE);  // ??USART1
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);  // ??????
}

// **USART1 ??????**
void USART1_IRQHandler(void)
{
    uint8_t dat;

    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) // ????????
    {
        dat = USART_ReceiveData(USART1); // ????????

        if (dat >= '1' && dat <= '5') // ?????????????
        {
            mode = dat - '1';  // ????????????
        }
        else
        {
            // ?? error
            USART_SendData(USART1, 'e');
            while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
            USART_SendData(USART1, 'r');
            while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
            USART_SendData(USART1, 'r');
            while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
            USART_SendData(USART1, 'o');
            while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
            USART_SendData(USART1, 'r');
            while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
        }
    }
}

// **??USART1??**
void NVIC_USART1Enable(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  // ???????

    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn; // ??USART1??
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;  // ???????
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;  // ??????
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  // ????
    NVIC_Init(&NVIC_InitStructure);  // ???????
}

// **TIM3 ???**
void TIM3_Initialization(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);  // ??TIM3??

    // ??TIM3????,????????
    TIM_TimeBaseStructure.TIM_Period = 1000 - 1;  // ????????1?
    TIM_TimeBaseStructure.TIM_Prescaler = 72 - 1;  // 72MHz / 72 = 1MHz, 1MHz / 1000 = 1ms
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);  // ?????????
    NVIC_EnableIRQ(TIM3_IRQn);  // ??TIM3??

    TIM_Cmd(TIM3, ENABLE);  // ??TIM3
}

// **TIM3 ??????**
// **TIM3 ??????**
void TIM3_IRQHandler(void)
{
    static uint16_t ms_counter = 0; // ???????????????

    if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(TIM3, TIM_IT_Update);  // ??????

        ms_counter++; // ??1ms??,????1

        if (ms_counter >= 1000) // ???????1000ms (1?)
        {
            ms_counter = 0; // ?????

            // ??LED?? (????????1?????)
            switch (mode)
            {
                case 0: GPIOB->ODR = ~(Mode1[i]); break;
                case 1: GPIOB->ODR = ~(Mode2[i]); break;
                case 2: GPIOB->ODR = ~(Mode3[i]); break;
                case 3: GPIOB->ODR = ~(Mode4[i]); break;
                case 4: GPIOB->ODR = ~(Mode5[i]); break;
            }

            i++;
            if (i > 7) i = 0;  // ???? (8??? 0-7)
        }
    }
}

// **????**
void Show_Message(void)
{
    printf("USART Baudrate: %d, 8-N-1\n", 9600);  // ??USART??
}
