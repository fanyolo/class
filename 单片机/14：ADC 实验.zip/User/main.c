#include <stdio.h>
#include "stm32f10x.h" // Ensure all necessary STM32F10x peripheral headers are included (e.g., stm32f10x_adc.h, stm32f10x_dma.h, stm32f10x_tim.h, stm32f10x_gpio.h, stm32f10x_rcc.h, misc.h)

// ADC???? (ADC Sampling Data)
uint16_t iDMA_ADCConvervalue[4] = {0, 0, 0, 0}; // ??ADC???,?? AIN10, AIN11, AIN16, AIN17 (Stores raw ADC values, order: AIN10, AIN11, AIN16, AIN17)
float calculated_values[4] = {0.0f, 0.0f, 0.0f, 0.0f}; // ????????? (?????) (Stores converted actual values - voltage or temperature)

// STM32F103 V25 and Avg_Slope typical values (refer to your specific device datasheet)
#define V25             1.43f   // Voltage at 25�C (typical V)
#define AVG_SLOPE       0.0043f // Average slope (V/�C) (4.3mV/�C)
#define VREFINT_CAL     1.2f    // Typical Vrefint voltage (V), used for reference or calibration

// ???? (Function Declarations)
void NVIC_Configuration(void);
void USART1_IOInit(void);
void USART1Init(uint32_t BAUDRATE);
void DMA_ADCResultSend_Init(uint32_t pAdrr, uint32_t mAdrr, uint32_t ilen);
void ADC_RegularDMAEnablScan_Init(ADC_TypeDef* ADCx);
void TIM3_Init(void);
void TIM3_IRQHandler(void);
int fputc(int ch, FILE *f);
int fgetc(FILE *f);

int main(void)
{
    // ????? (Initialize USART1)
    USART1Init(9600);
    printf("Experiment 14: ADC Multi-channel Test (TIM3 Interrupt Triggered)\r\n");

    // ???NVIC (????TIM3??) (Initialize NVIC, especially for TIM3 interrupt)
    NVIC_Configuration();

    // ???DMA?? (??ADC) (Initialize DMA configuration for ADC)
    DMA_ADCResultSend_Init((uint32_t)(&(ADC1->DR)), (uint32_t)iDMA_ADCConvervalue, 4);

    // ???ADC (Initialize ADC)
    ADC_RegularDMAEnablScan_Init(ADC1);

    // ?????? TIM3, ? 10 ????? (Initialize Timer TIM3, interrupt every 10 seconds)
    TIM3_Init();

    printf("System Initialized. ADC data will be sent via USART1 every 10 seconds by TIM3 interrupt.\r\n");

    while (1)
    {
        // ??????????????????? (Main loop can perform other tasks or enter low-power mode)
        // ADC???????????TIM3_IRQHandler (ADC data processing and sending moved to TIM3_IRQHandler)
    }
}

void NVIC_Configuration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;

    // ??NVIC?????: 2??????,2????? (Configure NVIC Priority Group: 2 bits for preemption priority, 2 bits for subpriority)
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

    // ?????TIM3?? (Enable and configure TIM3 interrupt)
    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; // ??????? (Set preemption priority)
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;        // ?????? (Set subpriority)
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;           // ?????? (Enable interrupt channel)
    NVIC_Init(&NVIC_InitStructure);
}

void USART1_IOInit(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); // ??GPIOA?? (Enable GPIOA clock)

    // ??PA9?TX (Configure PA9 as TX)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; // ?????? (Alternate function push-pull)
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // ??PA10?RX (Configure PA10 as RX)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; // ???? (Input floating)
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void USART1Init(uint32_t BAUDRATE)
{
    USART_InitTypeDef USART_InitStructure;
    USART1_IOInit(); // ???USART1?GPIO (Initialize USART1 GPIO)
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE); // ??USART1?? (Enable USART1 clock)

    USART_InitStructure.USART_BaudRate = BAUDRATE;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART1, &USART_InitStructure);
    USART_Cmd(USART1, ENABLE); // ??USART1 (Enable USART1)
}

// ???printf?USART1 (Redirect printf to USART1)
int fputc(int ch, FILE *f)
{
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET); // ????????? (Wait for transmit buffer to be empty)
    USART_SendData(USART1, (uint16_t)ch);
    return ch;
}

// ???scanf (??????) (Redirect scanf - not used in this experiment)
int fgetc(FILE *f)
{
    while (USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == RESET); // ??????? (Wait for data to be received)
    return (int)USART_ReceiveData(USART1);
}

void DMA_ADCResultSend_Init(uint32_t pAdrr, uint32_t mAdrr, uint32_t ilen)
{
    DMA_InitTypeDef DMA_InitStruct;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE); // ??DMA1?? (Enable DMA1 clock)
    DMA_DeInit(DMA1_Channel1); // ??DMA1??1 (Reset DMA1 Channel 1)

    DMA_InitStruct.DMA_PeripheralBaseAddr = pAdrr; // ???? (ADC?????) (Peripheral address - ADC data register)
    DMA_InitStruct.DMA_MemoryBaseAddr = mAdrr;     // ???? (Memory address)
    DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralSRC; // ??????:????? (Data direction: peripheral to memory)
    DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Disable; // ??????? (Peripheral address no increment)
    DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;       // ?????? (Memory address increment)
    DMA_InitStruct.DMA_BufferSize = ilen;                       // ????? (Buffer size)
    DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord; // ??????:??(16?) (Peripheral data size: HalfWord - 16-bit)
    DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord; // ??????:??(16?) (Memory data size: HalfWord - 16-bit) *** CORRECTED TYPO HERE ***
    DMA_InitStruct.DMA_Mode = DMA_Mode_Circular;                // ???? (Circular mode)
    DMA_InitStruct.DMA_Priority = DMA_Priority_High;            // ???? (High priority)
    DMA_InitStruct.DMA_M2M = DMA_M2M_Disable;                   // ???????? (Not memory-to-memory mode)
    DMA_Init(DMA1_Channel1, &DMA_InitStruct);                   // ???DMA??1 (Initialize DMA1 Channel 1)
    DMA_Cmd(DMA1_Channel1, ENABLE);                             // ??DMA??1 (Enable DMA1 Channel 1)
}

void ADC_RegularDMAEnablScan_Init(ADC_TypeDef* ADCx)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    ADC_InitTypeDef ADC_InitStruct;

    // ??ADC1???IO??? (Enable ADC1 and corresponding GPIO clock)
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_ADC1, ENABLE);

    // ?? AIN10 (PC0) ? AIN11 (PC1) ????? (Configure AIN10 (PC0) and AIN11 (PC1) as analog input)
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AIN; // ?????? (Analog input mode)
    GPIO_Init(GPIOC, &GPIO_InitStruct);

    // ADC????? (ADC clock prescaler)
    // e.g., PCLK2 divided by 6 (72MHz/6 = 12MHz, ADC clock should not exceed 14MHz)
    RCC_ADCCLKConfig(RCC_PCLK2_Div6);

    // ADC ??? (ADC Initialization)
    ADC_InitStruct.ADC_Mode = ADC_Mode_Independent;       // ???? (Independent mode)
    ADC_InitStruct.ADC_ScanConvMode = ENABLE;             // ?????? (Scan conversion mode enabled)
    ADC_InitStruct.ADC_ContinuousConvMode = ENABLE;       // ???????? (Continuous conversion mode enabled)
    ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None; // ????? (No external trigger)
    ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;   // ????? (Data right alignment)
    ADC_InitStruct.ADC_NbrOfChannel = 4;                  // ?????? (Number of channels to be converted)
    ADC_Init(ADCx, &ADC_InitStruct);

    // ????????????? (Configure regular channel sequence and sampling time)
    // Longer sampling time can improve accuracy, especially for internal sensors
    ADC_RegularChannelConfig(ADCx, ADC_Channel_10, 1, ADC_SampleTime_239Cycles5); // AIN10 (PC0)
    ADC_RegularChannelConfig(ADCx, ADC_Channel_11, 2, ADC_SampleTime_239Cycles5); // AIN11 (PC1)
    ADC_RegularChannelConfig(ADCx, ADC_Channel_16, 3, ADC_SampleTime_239Cycles5); // ????? (Temperature sensor)
    ADC_RegularChannelConfig(ADCx, ADC_Channel_17, 4, ADC_SampleTime_239Cycles5); // ?????? (Internal reference voltage)

    // ??ADC (Enable ADC)
    ADC_Cmd(ADCx, ENABLE);

    // ??????????Vrefint?? (Enable internal temperature sensor and Vrefint channel)
    ADC_TempSensorVrefintCmd(ENABLE);

    // ADC?? (ADC Calibration - recommended for better accuracy)
    ADC_ResetCalibration(ADCx); // ??????? (Reset calibration registers)
    while(ADC_GetResetCalibrationStatus(ADCx)); // ?????? (Wait for reset to complete)
    ADC_StartCalibration(ADCx); // ???? (Start calibration)
    while(ADC_GetCalibrationStatus(ADCx)); // ?????? (Wait for calibration to complete)

    // ??ADC?DMA?? (Enable ADC DMA request)
    ADC_DMACmd(ADCx, ENABLE);

    // ????ADC?? (???????,??????) (Software start ADC conversion - once for continuous mode)
    ADC_SoftwareStartConvCmd(ADCx, ENABLE);
}

void TIM3_Init(void) // ??:10????? (Target: interrupt every 10 seconds)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStruct;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); // ??TIM3?? (Enable TIM3 clock)

    // TIM3 ?????? PCLK1. ?? SystemCoreClock = 72MHz, APB1 Prescaler = 2, then PCLK1 = 36MHz.
    // If TIMxCLK = PCLK1 (if APB1 prescaler = 1) or TIMxCLK = PCLK1*2 (if APB1 prescaler > 1)
    // Assuming TIM3CLK = 72MHz (e.g. SystemCoreClock=72MHz, APB1 prescaler=1, so PCLK1=72MHz, TIM3CLK = PCLK1)
    // Or if SystemCoreClock=72MHz, APB1 prescaler=2, PCLK1=36MHz, then TIM3CLK is often PCLK1*2 = 72MHz.
    // Check your specific clock configuration. For this calculation, we assume TIM3CLK = 72MHz.

    // Update_event_frequency = TIM_CLK / ((PSC+1)*(ARR+1))
    // We want 0.1 Hz (10 seconds).
    // 0.1 = 72,000,000 / ((PSC+1)*(ARR+1))
    // (PSC+1)*(ARR+1) = 720,000,000
    // To keep ARR (TIM_Period) within uint16_t (max 65535):
    // Let ARR+1 = 50000 (ARR = 49999)
    // Then PSC+1 = 720,000,000 / 50000 = 14400
    // So, PSC = 14399
    TIM_TimeBaseStruct.TIM_Period = 49999;  // ?????? (ARR - Auto-Reload Register)
    TIM_TimeBaseStruct.TIM_Prescaler = 14399; // ????? (PSC - Prescaler)
    TIM_TimeBaseStruct.TIM_ClockDivision = TIM_CKD_DIV1; // ?????? (Clock division)
    TIM_TimeBaseStruct.TIM_CounterMode = TIM_CounterMode_Up; // ?????? (Up-counting mode)
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStruct);

    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE); // ?????? (Enable update interrupt)
    TIM_Cmd(TIM3, ENABLE);                     // ????? (Start timer)
}

void TIM3_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET) // ??TIM3???????? (Check if TIM3 update interrupt occurred)
    {
        TIM_ClearITPendingBit(TIM3, TIM_IT_Update); // ??TIM3??????? (Clear TIM3 update interrupt pending bit)

        uint16_t adc_raw;
        float voltage_temp_sensor; // ???????????? (Intermediate voltage for temperature sensor)
        float temperature_celsius;

        // --- ??AIN10 (PC0 - ????) (Process AIN10 - Fixed Voltage) ---
        adc_raw = iDMA_ADCConvervalue[0];
        calculated_values[0] = (adc_raw / 4095.0f) * 3.3f; // ??VDDA=3.3V (Assuming VDDA=3.3V)

        // --- ??AIN11 (PC1 - ????) (Process AIN11 - Adjustable Voltage) ---
        adc_raw = iDMA_ADCConvervalue[1];
        calculated_values[1] = (adc_raw / 4095.0f) * 3.3f;

        // --- ??AIN16 (???????) (Process AIN16 - Internal Temperature Sensor) ---
        adc_raw = iDMA_ADCConvervalue[2];
        voltage_temp_sensor = (adc_raw / 4095.0f) * 3.3f; // VSENSE
        temperature_celsius = ((V25 - voltage_temp_sensor) / AVG_SLOPE) + 25.0f;
        calculated_values[2] = temperature_celsius; // ????? (Store temperature value)

        // --- ??AIN17 (?????? Vrefint) (Process AIN17 - Internal Reference Voltage Vrefint) ---
        adc_raw = iDMA_ADCConvervalue[3];
        calculated_values[3] = (adc_raw / 4095.0f) * 3.3f; // ???Vrefint?? (Measured Vrefint voltage)

        // ???????? (Send data via USART)
        printf(" ADC ���� (10s һ��) \r\n");
        printf("AIN10 : %.3f V\r\n", calculated_values[0]);
        printf("AIN11 : %.3f V\r\n", calculated_values[1]);
        printf("AIN16 : %.2f C \r\n", calculated_values[2] );
        printf("AIN17 : %.3f V \r\n", calculated_values[3]);
    }
}
// Ensure a newline at the end of the file
