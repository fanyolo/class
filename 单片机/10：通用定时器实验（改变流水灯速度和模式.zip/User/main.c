#include "stm32f10x.h"

void TIM5_Initialization(uint16_t PSC_Value, uint16_t ARR_Value);
void GPIO_Initialization(void);
void SysTick_Configuration(void);
void TIM5_IRQHandler(void);
void SysTick_Handler(void);

uint8_t mode = 0;  
uint16_t speed = 10000;  
uint8_t key1_flag = 0, key2_flag = 0;  

int main(void)
{
    GPIO_Initialization();
    SysTick_Configuration();
    TIM5_Initialization(7200, speed);  

    while(1);
}

// GPIO 初始化（LED + 按键）
void GPIO_Initialization(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    // LED (PB0, PB1, PB5)
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // KEY1 (PA0) - 上拉输入
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // KEY2 (PC13) - 上拉输入
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
}

// TIM5 初始化
void TIM5_Initialization(uint16_t PSC_Value, uint16_t ARR_Value)
{
    NVIC_InitTypeDef NVIC_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = TIM5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    TIM_DeInit(TIM5);
    TIM_TimeBaseStructure.TIM_Period = ARR_Value - 1;
    TIM_TimeBaseStructure.TIM_Prescaler = PSC_Value - 1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM5, &TIM_TimeBaseStructure);

    TIM_ClearFlag(TIM5, TIM_FLAG_Update);
    TIM_ITConfig(TIM5, TIM_IT_Update, ENABLE);
    TIM_Cmd(TIM5, ENABLE);
}

// TIM5 中断处理
void TIM5_IRQHandler(void)
{
    static uint8_t i = 0;
    unsigned int Mode1[8] = {0x01, 0x02, 0x20, 0x03, 0x21, 0x22, 0x23, 0x00};  
    unsigned int Mode2[8] = {0x01, 0x02, 0x20, 0x00, 0x20, 0x02, 0x01, 0x00};  
    unsigned int Mode3[8] = {0x23, 0x22, 0x21, 0x03, 0x20, 0x02, 0x01, 0x00};  

    if (TIM_GetITStatus(TIM5, TIM_IT_Update) == SET)
    {
        TIM_ClearITPendingBit(TIM5, TIM_IT_Update);

        switch (mode)
        {
            case 0: GPIOB->ODR = ~Mode1[i]; break;
            case 1: GPIOB->ODR = ~Mode2[i]; break;
            case 2: GPIOB->ODR = ~Mode3[i]; break;
        }

        i = (i + 1) % 8;
    }
}

// SysTick 配置，每 10ms 扫描按键
void SysTick_Configuration(void)
{
    SysTick_Config(SystemCoreClock / 100);  // 10ms
}

// SysTick 按键扫描
void SysTick_Handler(void)
{
    static uint8_t key1_last = 1, key2_last = 1;

    uint8_t key1_now = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0);  
    uint8_t key2_now = GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13);  

    // KEY1 (调整速度)
    if (key1_last == 1 && key1_now == 0)
    {
        key1_flag = 1;
    }
    if (key1_last == 0 && key1_now == 1 && key1_flag)
    {
        key1_flag = 0;
        speed = (speed == 10000) ? 5000 : ((speed == 5000) ? 2000 : 10000);
        TIM5_Initialization(7200, speed);
    }
    key1_last = key1_now;

    // KEY2 (切换模式)
    if (key2_last == 1 && key2_now == 0)
    {
        key2_flag = 1;
    }
    if (key2_last == 0 && key2_now == 1 && key2_flag)
    {
        key2_flag = 0;
        mode = (mode + 1) % 3;  
    }
    key2_last = key2_now;
}
