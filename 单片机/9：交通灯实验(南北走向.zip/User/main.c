#include "stm32f10x.h"

/* 定义两个引脚：PB0 控制 NS绿/ EW红，PB5 控制 NS红/ EW绿 */
#define PIN_GREEN  GPIO_Pin_0   // NS 绿灯（同时驱动 EW 红灯）
#define PIN_RED    GPIO_Pin_5   // NS 红灯（同时驱动 EW 绿灯）

/* 交通灯状态定义（以NS方向为准） */
typedef enum {
    STATE_NS_GREEN, // NS: 绿60s, EW: 红
    STATE_YELLOW,   // NS: 黄5s,  EW: 黄
    STATE_NS_RED    // NS: 红30s, EW: 绿
} TrafficState;

volatile TrafficState state = STATE_NS_GREEN;
volatile uint32_t timer_counter = 0;

/* 函数声明 */
void TIM7_Initialization(uint16_t PSC_Value, uint16_t ARR_Value);
void GPIOB_Initialization(void);
void TIM7_IRQHandler(void);

int main(void)
{
    TIM7_Initialization(7200, 10000);  // 1秒定时中断（预分频和ARR参数根据系统时钟设置）
    GPIOB_Initialization();
    
    while (1)
    {
        
    }
}

/* 配置 GPIOB 两个引脚为推挽输出 */
void GPIOB_Initialization(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin = PIN_GREEN | PIN_RED;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}

/* 初始化 TIM7，产生1秒中断 */
void TIM7_Initialization(uint16_t PSC_Value, uint16_t ARR_Value)
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    
    NVIC_InitStructure.NVIC_IRQChannel = TIM7_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    RCC->APB1ENR |= (1 << 5);  // 使能 TIM7 时钟
    
    TIM7->PSC = PSC_Value - 1;
    TIM7->ARR = ARR_Value - 1;
    TIM7->CNT = 0;
    TIM7->SR = 0;
    TIM7->DIER |= TIM_DIER_UIE;  // 允许更新中断
    TIM7->CR1 |= TIM_CR1_CEN;    // 启动定时器
}

//TIM7 1秒  南北走向
void TIM7_IRQHandler(void)
{
    if (TIM7->SR & TIM_SR_UIF)
    {
        TIM7->SR &= ~TIM_SR_UIF;  // 清除中断标志
        timer_counter++;
        
        switch(state)
        {
            case STATE_NS_GREEN:
                GPIOB->ODR = PIN_RED;  
                if (timer_counter >= 60)
//if (timer_counter >= 5)
                {
                    state = STATE_YELLOW;
                    timer_counter = 0;
                }
                break;
                
            case STATE_YELLOW:
                GPIO_ResetBits(GPIOB, PIN_RED|PIN_GREEN);
                if (timer_counter >= 5)
//if (timer_counter >= 1)
                {
                    state = STATE_NS_RED;
                    timer_counter = 0;
                }
                break;
                
            case STATE_NS_RED:
                GPIOB->ODR = PIN_GREEN;
                if (timer_counter >= 30)
//if (timer_counter >= 3)
                {
                    state = STATE_NS_GREEN;
                    timer_counter = 0;
                }
                break;
                
            default:
                state = STATE_NS_GREEN;
                timer_counter = 0;
                break;
        }
    }
}
